
var express = require('express');
var router = express.Router();

router.post('',(req,res)=>{
    DB.push(req.body);
    addition=parseInt(req.body.num1)+parseInt(req.body.num2)
  
    myResult = "{addition:"+addition+"}"
  
    console.log(myResult);
    res.status(201).send(myResult);
  });