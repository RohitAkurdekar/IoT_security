var express = require('express');
var axios = require('axios')
var router = express.Router();


// Program to make a simple GET request and parse the Response Body
const HOST = "http://localhost:";
const PORT = "4000"
const PATH = "/"

REQUEST_BODY = {
  num1:0,
  num2:0
}


router.post('',(req,res)=>{
    console.log(req.body);
    REQUEST_BODY = req.body;

    axios.post(HOST + PORT + PATH, REQUEST_BODY)
     .then((response)=>{
         const RESPONSE_BODY  = JSON.stringify(response.data, null,2);
         console.log("Data: "+RESPONSE_BODY+". Response Code: "+ response.status)
         res.status(201).send(RESPONSE_BODY);
     }).catch(error=>{
         console.log(error);
     })
 
 });


 router.get('',(req,res)=>{
    res.sendFile('user.html', { root: __dirname });
  })