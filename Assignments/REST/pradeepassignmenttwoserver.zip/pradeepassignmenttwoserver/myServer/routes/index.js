var express = require('express');
var axios = require('axios')
var router = express.Router();


// Program to make a simple GET request and parse the Response Body
const HOST = "http://localhost:";
const PORT = "4000"
const PATH = "/sensor/value"

REQUEST_BODY = {
  num1:0,
  num2:0
}

// let DB = [];
// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'CDAC IoT Protocols' });
// });

// // GET request with JSON object
// router.get('/json',(req,res)=>{
//   res.status(200).json({sensor:'temp', value: '24.5', unit:'F'})
// })

 router.post('/sensor/value',(req,res)=>{
   // DB.push(req.body);
   console.log(req.body);
   REQUEST_BODY = req.body;
  //  RESPONSE_BODY = ""
   axios.post(HOST + PORT + PATH, REQUEST_BODY)
    .then((response)=>{
        const RESPONSE_BODY  = JSON.stringify(response.data, null,2);
        console.log("Data: "+RESPONSE_BODY+". Response Code: "+ response.status)
        res.status(201).send(RESPONSE_BODY);
    }).catch(error=>{
        console.log(error);
    })

    // console.log(RESPONSE_BODY);
});
  
// router.put('/sensor/value',(req,res)=>{
//   let index = req.body.index;
//   let value = req.body.value;
  
//   if(DB.length >=index){
//     DB[index] = value;
//     res.status(200).json({message:'Resource updated'});
//   } else {
//     for(let i=0; i<=index; i++){
//       DB.push(-1);
//       console.log("PUT")
//     }
//     DB[index] = value;
//     res.status(201).json({message:'Resource created'});
//   }
  
// });

router.get('/sensor/value',(req,res)=>{
  res.sendFile('user.html', { root: __dirname });
})

// router.delete('/sensor/value/:index',(req,res)=>{
//   if(req.params){
//     let index = req.params.index;
//     index==0?DB.splice(0,1): DB.splice(index,index)
//   } else {
//     DB =[];
//   }
//   res.status(200).json({message:'Resources deleted'})
// })

// router.get('/sensor/query/:id?',(req,res)=>{
//   if(req.query.id >  DB.length){
//     res.status(404).json({message: "Resource not available"})  
//   } else {
//     const result = DB[req.query.id];
//     res.status(200).json({data: JSON.stringify(result)})
//   }
// })
// const axios = require('axios')


// axios.post(HOST + PORT + PATH, REQUEST_BODY)
//     .then((response)=>{
//         const RESPONSE_BODY  = JSON.stringify(response.data, null,2);
//         console.log("Data: "+RESPONSE_BODY+". Response Code: "+ response.status)
//     }).catch(error=>{
//         console.log(error);
//     })

module.exports = router;
