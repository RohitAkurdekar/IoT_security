var express = require('express');
var router = express.Router();

let DB = [];
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'CDAC IoT Protocols' });
});

// GET request with JSON object
router.get('/json',(req,res)=>{
  res.status(200).json({sensor:'temp', value: '24.5', unit:'F'})
})

router.post('/sensor/value',(req,res)=>{
  DB.push(req.body);
  addition=parseInt(req.body.num1)+parseInt(req.body.num2)

  myResult = "{addition:"+addition+"}"

  console.log(myResult);
  res.status(201).send(myResult);
});
  
router.put('/sensor/value',(req,res)=>{
  let index = req.body.index;
  let value = req.body.value;
  
  if(DB.length >=index){
    DB[index] = value;
    res.status(200).json({message:'Resource updated'});
  } else {
    for(let i=0; i<=index; i++){
      DB.push(-1);
      console.log("PUT")
    }
    DB[index] = value;
    res.status(201).json({message:'Resource created'});
  }
  
});

router.get('/sensor/value',(req,res)=>{
  res.status(200).json({data: DB});
})

router.delete('/sensor/value/:index',(req,res)=>{
  if(req.params){
    let index = req.params.index;
    index==0?DB.splice(0,1): DB.splice(index,index)
  } else {
    DB =[];
  }
  res.status(200).json({message:'Resources deleted'})
})

router.get('/sensor/query/:id?',(req,res)=>{
  if(req.query.id >  DB.length){
    res.status(404).json({message: "Resource not available"})  
  } else {
    const result = DB[req.query.id];
    res.status(200).json({data: JSON.stringify(result)})
  }
})

module.exports = router;
