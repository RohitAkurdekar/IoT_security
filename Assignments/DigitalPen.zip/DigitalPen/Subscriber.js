// Program to publish data to Broker on TOPIC
const mqtt = require('mqtt');


// Importing required modules
const { response } = require("express");
const express = require("express");
const app=express()


// ----------------------------------------------------------------

const HOST = 'mqtt://localhost:';
const PORT = '1883';

function sendData(data,uname)
{
}
// Handling get request from the client side
app.get("/",(req,res,next)=>{

	// Checking the header of the authorization
	var authheader=req.headers.authorization;
	console.log(authheader)
	if(!authheader){
		
		var err=new Error("You are not authenticated")
		// Set the header for the response
		res.setHeader("WWW-Authenticate",'Basic')
		err.status=401
		return next(err)
	
	}
	console.log(authheader)

	// Decrypt the user name and the password
	var auth = new Buffer.from(authheader.split(' ')[1],
	'base64').toString().split(':');
	var user = auth[0];
	var pass = auth[1];

	// Checking the details
	if (user == 'User1' && pass == 'password') {

//----------------------------------------------------------------

            const subscriber = mqtt.connect(HOST + PORT,{
                protocolId:"MQTT",
                protocolVersion:4,
                username:'diot',
                password:'diot',
                clean:false,
                clientId:"diot002",
                qos:2
            });

            // MQTT Topic to Publish data to


            USER = user

            const TOPIC = 'cdac/rohit/' + USER;



            const WILL_TOPIC = "cdac/device/dead"

            // Event to Check BROKER connection
            subscriber.on('connect',()=>{
                
                console.log("Connected to MQTT Broker!");

                // Publish the data
                subscriber.subscribe([TOPIC],{qos:1}, (err, granted)=>{
                    if(!err){
                        // console.log(`Granted. Topic: ${granted[0].topic}, QoS: ${granted[0].qos}`);
                    }
                });
            })

            subscriber.on('message',(topic,data)=>{
                console.log(`${data.toString()}`);

                res.send(data.toString())
            })

	
	} // -------------elif ------------
    else if (user == 'User2' && pass == 'password') {
        //----------------------------------------------------------------
       
                    const subscriber = mqtt.connect(HOST + PORT,{
                        protocolId:"MQTT",
                        protocolVersion:4,
                        username:'diot',
                        password:'diot',
                        clean:false,
                        clientId:"diot002",
                        qos:2
                    });
        
                    // MQTT Topic to Publish data to
        
        
                    USER = user
        
                    const TOPIC = 'cdac/rohit/' + USER;
        
        
        
                    const WILL_TOPIC = "cdac/device/dead"
        
                    // Event to Check BROKER connection
                    subscriber.on('connect',()=>{
                        
                        console.log("Connected to MQTT Broker!");
        
                        // Publish the data
                        subscriber.subscribe([TOPIC],{qos:1}, (err, granted)=>{
                            if(!err){
                                // console.log(`Granted. Topic: ${granted[0].topic}, QoS: ${granted[0].qos}`);
                            }
                        });
                    })
        
                    subscriber.on('message',(topic,data)=>{
                        console.log(`${data.toString()}`);
        
                        res.send(data.toString())
                    
                    })
        
            
            } 
            else {
                var err = new Error('You are not authenticated!');
                res.setHeader('WWW-Authenticate', 'Basic');
                err.status = 401;
                return next(err);
            }

})
app.listen(3000,()=>{
console.log("Server is starting")
})
