# Secured digital pen

A digital pen that converts gestures or pen movements into characters and upload data to server over MQTT protocol.

Server authorizes user using credentials and displays data received from pen.