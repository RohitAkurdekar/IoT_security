var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
// importing user context
const Pen = require("./../model/pen");

// Register
router.post("/register", async (req, res) => {

  // Our register logic starts here
  try {
    // Get user input
    const { id, color, ink, password } = req.body;

    // Validate user input
    if (!(id && color && ink && password)) {
      res.status(400).send("All input is required");
    }

    // check if user already exist
    // Validate if user exist in our database
    const oldPen = await Pen.findOne({ id });

    if (oldPen) {
      return res.status(409).send("ID Already Exist. Please Login");
    }

    //Encrypt user password
    encryptedPassword = await bcrypt.hash(password, 10);

    // Create user in our database
    const pen = await Pen.create({
      id,
      color,
      ink,
      password: encryptedPassword,
    });

    // Create token
    const token = jwt.sign(
      { pen_id: pen.id },
      "my_secret_key",
      {
        expiresIn: "2h",
      }
    );
    // save user token
    pen.token = token;

    // return new user
    res.status(201).json(pen);
  } catch (err) {
    console.log(err);
  }
  // Our register logic ends here
});


// Login
router.post("/login", (req, res) => {
// our login logic goes here
});


var data = [
  {"id":1,"color":"red","ink":60},
  {"id":2,"color":"blue","ink":20},
  {"id":3,"color":"black","ink":100},
  {"id":4,"color":"red","ink":6}
]

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.json(data[2]);
});

router.post('/', function(req, res, next) {
  res.json({"id":5});
});

router.put('/', function(req, res, next) {
  res.json({"id":5});
});

router.delete('/', function(req, res, next) {
  res.json({"id":5});
});

module.exports = router;
