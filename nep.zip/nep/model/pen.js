const mongoose = require("mongoose");

const penSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  color: { type: String, default: null },
  ink: { type: Number },
  password: { type: String },
  token: { type: String },
});

module.exports = mongoose.model("pen", penSchema);